package ru.redstonemaster.client.gui;

import java.util.List;
import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;
import net.minecraft.class_7919;

public class RedstoneMasterScreen extends class_437 {
	private static final double PANEL_SCALE = 0.8;
	private static final int PANEL_PADDING = 8;
	private static final int NAV_BAR_HEIGHT = 20;
	private static final int ICON_BUTTON_SIZE = 20;
	private static final int CLOSE_BUTTON_GAP = 2;
	private static final int TITLE_TOP_PADDING = 4;
	private static final int TITLE_TO_NAV_GAP = 2;
	private static final int NAV_DOWN_OFFSET = 4;
	private static final int CONTENT_TOP_GAP = 6;
	/** Цвета в формате ARGB: без альфа-канала (0x00FFFFFF) текст не виден. */
	private static final int TEXT_COLOR = 0xFFFFFFFF;
	private static final int IMAGE_COLOR = 0xFFFFFFFF;
	private static final int LINE_COLOR = 0xFF000000;
	private static final int TITLE_COLOR = 0xFF800020;
	private static final float TITLE_SCALE = 1.5f;
	private static final class_2960 MAIN_MENU_PHOTO = class_2960.method_60655(
			"redstone_master", "textures/gui/photo1_main_menu.png");
	private static final int MAIN_MENU_PHOTO_SIZE = 1024;
	private static final int CONTENT_INNER_PADDING = 6;
	private static final int TEXT_TO_PHOTO_GAP = 8;

	private RedstoneMasterTab currentTab = RedstoneMasterTab.MAIN_MENU;

	private int panelX;
	private int panelY;
	private int panelWidth;
	private int panelHeight;
	private int titleY;
	private int navY;
	private int separatorY;
	private int contentX;
	private int contentY;
	private int contentWidth;
	private int contentHeight;

	public RedstoneMasterScreen() {
		super(class_2561.method_43471("gui.redstone_master.title"));
	}

	@Override
	protected void method_25426() {
		this.updatePanelBounds();
		this.rebuildNavigation();
	}

	private void updatePanelBounds() {
		this.panelWidth = (int) (this.field_22789 * PANEL_SCALE);
		this.panelHeight = (int) (this.field_22790 * PANEL_SCALE);
		this.panelX = (this.field_22789 - this.panelWidth) / 2;
		this.panelY = (this.field_22790 - this.panelHeight) / 2;

		int innerX = this.panelX + PANEL_PADDING;
		int innerWidth = this.panelWidth - PANEL_PADDING * 2;

		this.titleY = this.panelY + PANEL_PADDING + TITLE_TOP_PADDING;
		int titleHeight = this.getScaledTitleHeight();
		this.separatorY = this.titleY + titleHeight + 2;
		this.navY = this.titleY + titleHeight + TITLE_TO_NAV_GAP + NAV_DOWN_OFFSET;
		this.contentX = innerX;
		this.contentY = this.navY + NAV_BAR_HEIGHT + CONTENT_TOP_GAP;
		this.contentWidth = innerWidth;
		this.contentHeight = this.panelY + this.panelHeight - PANEL_PADDING - this.contentY;
	}

	private void rebuildNavigation() {
		this.method_37067();

		int innerX = this.panelX + PANEL_PADDING;
		int innerWidth = this.panelWidth - PANEL_PADDING * 2;

		int closeAreaWidth = ICON_BUTTON_SIZE + CLOSE_BUTTON_GAP;
		int navButtonWidth = (innerWidth - closeAreaWidth) / 4;

		this.method_37063(class_4185.method_46430(
						class_2561.method_43471("gui.redstone_master.tab.main_menu"),
						button -> this.selectTab(RedstoneMasterTab.MAIN_MENU))
				.method_46434(innerX, this.navY, navButtonWidth, NAV_BAR_HEIGHT)
				.method_46431());

		this.method_37063(class_4185.method_46430(
						class_2561.method_43471("gui.redstone_master.tab.tutorial"),
						button -> this.selectTab(RedstoneMasterTab.TUTORIAL))
				.method_46434(innerX + navButtonWidth, this.navY, navButtonWidth, NAV_BAR_HEIGHT)
				.method_46431());

		this.method_37063(class_4185.method_46430(
						class_2561.method_43471("gui.redstone_master.tab.settings"),
						button -> this.selectTab(RedstoneMasterTab.SETTINGS))
				.method_46434(innerX + navButtonWidth * 2, this.navY, navButtonWidth, NAV_BAR_HEIGHT)
				.method_46431());

		this.method_37063(class_4185.method_46430(
						class_2561.method_43471("gui.redstone_master.search"),
						button -> this.selectTab(RedstoneMasterTab.SEARCH))
				.method_46434(innerX + navButtonWidth * 3, this.navY, navButtonWidth, NAV_BAR_HEIGHT)
				.method_46431());

		int closeX = innerX + navButtonWidth * 4 + CLOSE_BUTTON_GAP;
		this.method_37063(class_4185.method_46430(
						class_2561.method_43470("X"),
						button -> this.method_25419())
				.method_46434(closeX, this.navY, ICON_BUTTON_SIZE, ICON_BUTTON_SIZE)
				.method_46436(class_7919.method_47407(class_2561.method_43471("gui.redstone_master.close")))
				.method_46431());
	}

	private void selectTab(RedstoneMasterTab tab) {
		this.currentTab = tab;
	}

	@Override
	public void method_25410(int width, int height) {
		super.method_25410(width, height);
		this.updatePanelBounds();
		this.rebuildNavigation();
	}

	@Override
	public void method_25420(class_332 graphics, int mouseX, int mouseY, float delta) {
		// Оставляем 20% экрана прозрачными — виден мир или фон главного меню.
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
		this.method_57736(graphics, this.panelX, this.panelY, this.panelWidth, this.panelHeight);
		super.method_25394(graphics, mouseX, mouseY, delta);
		this.renderDecorations(graphics);
		this.renderContent(graphics);
	}

	private int getScaledTitleHeight() {
		return (int) Math.ceil(this.field_22793.field_2000 * TITLE_SCALE);
	}

	private class_2561 getTitleComponent() {
		return class_2561.method_43471("gui.redstone_master.title")
				.method_27696(class_2583.field_24360.method_10982(true));
	}

	private void renderTitle(class_332 graphics) {
		int centerX = this.panelX + this.panelWidth / 2;
		float anchorY = this.titleY + this.field_22793.field_2000 / 2.0f;

		var pose = graphics.method_51448();
		pose.pushMatrix();
		pose.translate(centerX, anchorY);
		pose.scale(TITLE_SCALE, TITLE_SCALE);
		graphics.method_27534(
				this.field_22793,
				this.getTitleComponent(),
				0,
				(int) (-this.field_22793.field_2000 / 2.0f),
				TITLE_COLOR
		);
		pose.popMatrix();
	}

	private void renderDecorations(class_332 graphics) {
		graphics.method_73198(this.panelX, this.panelY, this.panelWidth, this.panelHeight, LINE_COLOR);
		this.renderTitle(graphics);

		graphics.method_51738(
				this.panelX + PANEL_PADDING,
				this.panelX + this.panelWidth - PANEL_PADDING,
				this.separatorY,
				LINE_COLOR
		);

		graphics.method_73198(this.contentX, this.contentY, this.contentWidth, this.contentHeight, LINE_COLOR);
	}

	private void renderContent(class_332 graphics) {
		if (this.currentTab == RedstoneMasterTab.MAIN_MENU) {
			this.renderMainMenuContent(graphics);
			return;
		}

		this.renderTextContent(graphics, this.currentTab.getContent());
	}

	private void renderMainMenuContent(class_332 graphics) {
		int textX = this.contentX + CONTENT_INNER_PADDING;
		int textY = this.contentY + CONTENT_INNER_PADDING;
		int textWidth = this.contentWidth - CONTENT_INNER_PADDING * 2;

		textY = this.renderTextContentAt(graphics, RedstoneMasterTab.MAIN_MENU.getContent(), textX, textY, textWidth);
		textY += TEXT_TO_PHOTO_GAP;

		int photoAreaBottom = this.contentY + this.contentHeight - CONTENT_INNER_PADDING;
		int photoAreaHeight = photoAreaBottom - textY;
		int photoAreaWidth = this.contentWidth - CONTENT_INNER_PADDING * 2;

		if (photoAreaHeight <= 0 || photoAreaWidth <= 0) {
			return;
		}

		int photoSize = Math.min(photoAreaWidth, photoAreaHeight);
		int photoX = this.contentX + (this.contentWidth - photoSize) / 2;

		graphics.method_25293(
				class_10799.field_56883,
				MAIN_MENU_PHOTO,
				photoX,
				textY,
				0.0f,
				0.0f,
				photoSize,
				photoSize,
				MAIN_MENU_PHOTO_SIZE,
				MAIN_MENU_PHOTO_SIZE,
				MAIN_MENU_PHOTO_SIZE,
				MAIN_MENU_PHOTO_SIZE,
				IMAGE_COLOR
		);
	}

	private void renderTextContent(class_332 graphics, class_2561 text) {
		this.renderTextContentAt(
				graphics,
				text,
				this.contentX + CONTENT_INNER_PADDING,
				this.contentY + CONTENT_INNER_PADDING,
				this.contentWidth - CONTENT_INNER_PADDING * 2
		);
	}

	private int renderTextContentAt(class_332 graphics, class_2561 text, int textX, int textY, int textWidth) {
		List<class_5481> lines = this.field_22793.method_1728(text, textWidth);
		for (class_5481 line : lines) {
			graphics.method_51430(this.field_22793, line, textX, textY, TEXT_COLOR, true);
			textY += this.field_22793.field_2000;
		}
		return textY;
	}

	@Override
	public boolean method_25421() {
		return this.field_22787 != null && this.field_22787.method_47392();
	}
}
